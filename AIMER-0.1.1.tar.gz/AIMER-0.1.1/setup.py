import os.path
import setuptools
import AIMER

_APP_PATH = os.path.dirname(AIMER.__file__)

setuptools.setup(
    name = "AIMER",
    version = AIMER.__version__,
    description = "AIMER is a package to identify imprinting-like allele-specific methylated regions (AMR) from bisulfite sequencing data (WGBS or RRBS).",
    keywords = 'allele-specific methylated regions',
    author = 'ZhaoLab-TMU',
    author_email = 'zhaolab_tmu@163.com',
    url = ['https://github.com/ZhaoLab-TMU/AIMER','https://gitee.com/zhaolab_tmu/AIMER'],
    license = 'MIT',
    packages = ['AIMER'],
    scripts = ['bin/AIMER'],
    include_package_data = True,
    zip_safe = False,
    package_data = {
        'AIMER': [
            'get_bin.so','get_amr.so','bin_extension.so','resources/README.md','resources/mouse/m8.all.v2023.1.Mm.symbols.txt']
    },
    install_requires = ['numpy>=1.22.3','pyfasta>=0.5.2','gtfparse>=1.2.1','pandas>=1.4.2','pybedtools>=0.9.0','pyranges>=0.0.115','gtfparse>=1.2.1']
)
