# Cell type signature gene sets for mouse downloaded from
# https://www.gsea-msigdb.org/gsea/msigdb/download_file.jsp?filePath=/msigdb/release/2023.2.Mm/m8.all.v2023.2.Mm.symbols.gmt, 
# this script is used to convert the gmt format file to 
# the --annotation input file in the AIMER get_amr step, 
# the annotation file includes the Tissue and Gene columns.

suppressPackageStartupMessages({
  library(data.table)
  library(this.path)
  library(qusage)
  library(tidyr)
  library(dplyr)
  library(stringr)
})

dir <- this.path::this.dir()
setwd(dir = dir)

gmt <- read.gmt("m8.all.v2023.2.Mm.symbols.gmt")

gmt_df <- data.frame()
for (name in names(gmt)){
  gene_list <- gmt[name] %>% 
    unique() %>%
    unlist() %>%
    gsub('\n|\t|"| ','',.) %>%
    paste(.,collapse = ",")
  
  tmp_df <- data.frame(
    Standard_name = gsub("_"," ",name) %>% str_to_title(),
    Gene = gene_list
  )
  gmt_df <- rbind(gmt_df,tmp_df)
}

tissue_list <- c("Organogenesis","Aorta","Heart","Bladder","Brain","Brown Adipose",
                 "Diaphragm","Gonadal Adipose","Heart And Aorta","Kidney",
                 "Large Intestine","Liver","Lung","Mammary Gland",
                 "Marrow","Mesenteric Adipose","Pancreas","Skin","Spleen",
                 "Subcutaneous Adipose","Thymus","Tongue","Trachea","Uterus",
                 "Senistrachea Smooth Muscle","Limb Muscle")

gmt_df$Tissue <- ""
for (tissue in tissue_list){
  message(tissue)
  gmt_df[grep(tissue,gmt_df$Standard_name),"Tissue"] <- tissue
}

gmt_df$Tissue <- gsub("Senistrachea","Trachea",gmt_df$Tissue)

gmt_summary <- gmt_df %>%
  select(-c("Standard_name")) %>%
  group_by(Tissue) %>%
  summarise(Gene = paste(Gene,collapse = ",")) %>%
  group_by(Tissue) %>%
  summarise(Gene = unique(Gene))

fwrite(gmt_summary,"m8.all.v2023.2.Mm.symbols.gmt.xls",col.names = T,row.names = F,sep = "\t",quote = F)


