# Cell type signature gene sets for human downloaded from
# https://www.gsea-msigdb.org/gsea/msigdb/download_file.jsp?filePath=/msigdb/release/2023.2.Hs/c8.all.v2023.2.Hs.symbols.gmt
# this script is used to convert the gmt format file to 
# the --annotation file in the AIMER get_amr step, 
# the annotation file includes the Tissue and Gene columns.

suppressPackageStartupMessages({
  library(data.table)
  library(this.path)
  library(qusage)
  library(tidyr)
  library(dplyr)
  library(stringr)
})

dir <- this.path::this.dir()
setwd(dir = dir)

gmt <- read.gmt("c8.all.v2023.2.Hs.symbols.gmt")

gmt_df <- data.frame()
for (name in names(gmt)){
  gene_list <- gmt[name] %>% 
    unique() %>%
    unlist() %>%
    gsub('\n|\t|"| ','',.) %>%
    paste(.,collapse = ",")
  
  tmp_df <- data.frame(
    Standard_name = gsub("_"," ",name) %>% str_to_title(),
    Gene = gene_list
  )
  gmt_df <- rbind(gmt_df,tmp_df)
}

tissue_list <- c("Muscle","Liver","Duodenal","Esophageal","Gastric","Heart","Adrenal",
                 "Cerebellum","Eye","Intestine","Kidney","Lung","Pancreas","Placenta",
                 "Spleen","Stomach","Thymus","Olfactory Neuroepithelium","Ctx",
                 "Ovary","Esophagus","Bone Marrow","Retina","Midbrain Neurotypes","Pancreatic",
                 "Cord Blood","Pfc","Cerebrum","Main")

gmt_df$Tissue <- ""
for (tissue in tissue_list){
  message(tissue)
  gmt_df[grep(tissue,gmt_df$Standard_name),"Tissue"] <- tissue
}

gmt_df$Tissue <- gsub("Pancreatic","Pancreas",gmt_df$Tissue)
gmt_df$Tissue <- gsub("Retina","Eye",gmt_df$Tissue)
gmt_df$Tissue <- gsub("Stomach","Gastric",gmt_df$Tissue)

gmt_summary <- gmt_df %>% 
  filter(Tissue != "Main") %>%
  select(-c("Standard_name")) %>%
  group_by(Tissue) %>%
  summarise(Gene = paste(Gene,collapse = ",")) %>%
  group_by(Tissue) %>%
  summarise(Gene = unique(Gene))


fwrite(gmt_summary,"c8.all.v2023.2.Hs.symbols.gmt.xls",col.names = T,row.names = F,sep = "\t",quote = F)


